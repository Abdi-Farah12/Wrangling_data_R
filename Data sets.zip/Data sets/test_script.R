print("Hello FUCKING world")
a <- 10
a

my.age <- 35
pet <- 'goldfish'
hr.pay <- 12.25
bonus <- '4x'
fav.film <- 'Millennium Falcon'
hr.pay
fav.film
pet 
my.age

class(fav.film)
typeof(pet)
length(a)
attributes(pet)

# Vectors

name <- 'Andrew'
typeof(name)
length(name)

x <- c(1,2,3)
length(x)
attributes(x)

named.vec <- c('first' = 1, 'second' = 2, 'third' = 3)
attributes(named.vec)

c(1, 2, 3, 4, 5, 6, 7) 

assign("vector1",c(1,2,3,4,5,6,7))
vector1

sent = 'How long is this sentance'
length(sent)

str (1, 5.5, 100)

str (1L)

x <- c(4L, 6L)
is.integer(x)

vec <- c (FALSE, NA, TRUE, FALSE)
vec

authors <- c ("Andrew", "Joy")  
str (authors) 

comp <- c(2-4i, 1+3i-2, 55i) 
print(typeof(comp))

# Indexinf Vectors
b <- 10:15
b
b[1]
b[5]

# Explicit coercion
x <- c (1, 2, 3, 4, 5)
y <- c ("yes", "no") 
str (x)
str (y)

as.character (x) 
as.logical (y)

# Lists

# unnamed list
list_data <- list('red','green','yellow')
print(list_data)

# named list

basket_apples  <-  list ("Red", "Green", "Yellow") 
print (basket_apples)

# Manipulating list elements
# Adding list elements
basket_apples [4] <- 'white'

# Removing list elements
basket_apples [4] <- NULL

# Replacing list elements
basket_apples [3] <- 'pink'

# Merging and indexing lists in R
# Merging lists 

list1 <- list(5,6,7)
list2 <- list('thu', 'fri', 'sat')

merged_list <- c(list1,list2)
print(merged_list)

# Indexing lists 
days_week  <-  list ("Sunday", "Monday", "Tuesday", "Wednesday", 
                     "Thursday", "Friday", "Saturday")
days_week [5]
days_week [[3]]

# Matrices in R

b <- matrix (1:9, nrow = 3, ncol = 3)
print(b)

t(b)

dim (b)
attributes (b)

a = matrix (1:6, nrow = 3, ncol = 2)
a
b = matrix (1:9, nrow = 3, ncol = 3)
b

cbind(a,b)

C = matrix (1:6, nrow = 2, ncol = 3)  # Create a matrix C. 
D = matrix (1:9, nrow = 3, ncol = 3)  # Create a matrix D.
rbind(C,D)


z <- matrix (1:9, nrow = 3, ncol = 3, byrow = TRUE)
print (z)

y <- matrix (1:9, nrow = 3, ncol = 3)
print (y)

z[3,2]

z[, c(1,3)]
z[1,3]

rownames (z) <- c('top','middle', 'bottom')
colnames (z) <- c('left','middle','right')
print(z)

